# SIGOE · Backend (Flask + SQLite)

Este é o servidor da **Etapa 3**: uma API REST em Flask que guarda os dados em um
banco **SQLite** (`sigoe.db`). Ele também serve o front-end (a pasta acima), então
você acessa tudo em um único endereço.

## Como rodar

```bash
# a partir da pasta backend/
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Abra **http://localhost:5000**.

- Na primeira vez, o arquivo `sigoe.db` é criado e preenchido com dados de exemplo.
- Para zerar o banco: apague `sigoe.db` (ou use o botão "Reiniciar dados" em
  Configurações → Dados, ou `POST /api/reset`).

## Como funciona

- `app.py` — cria as tabelas, expõe a API `/api/...` e serve o front-end.
- `seed.py` — dados de demonstração (escola, turmas, alunos, professores etc.).
- O front (`js/db.js`) carrega tudo de `GET /api/state` ao iniciar e, a cada
  cadastro/edição/exclusão, envia a mudança para a API (write-through). Se o
  servidor estiver fora do ar, o app usa `localStorage` como reserva.

## Login (autenticação real)

Agora o acesso é protegido: sem login, a API responde 401 e o app mostra a tela
de entrada. Na primeira execução é criado um usuário administrador:

- **usuário:** `admin`
- **senha:** `sigoe2026`  ← troque assim que possível!

### Criar contas para os professores / trocar senha

```bash
python criar_usuario.py <usuario> <senha> "Nome Completo" email papel
# ex.: professor
python criar_usuario.py prof.ana Senha@123 "Ana Paula Ribeiro" ana@escola.pi.gov.br professor
# trocar a senha do admin
python criar_usuario.py admin NovaSenhaForte
```

As senhas são guardadas com **hash** (nunca em texto puro). Em produção, defina a
variável de ambiente `SIGOE_SECRET` com um valor secreto (assina os cookies de sessão).

## Tabelas

Uma tabela por coleção: `escolas, turmas, alunos, professores, responsaveis,
ocorrencias, eventos, notificacoes` (todas com `id, createdAt, updatedAt` +
campos próprios) e uma tabela `config` (chave/valor) para as preferências.

## Endpoints

| Método | Rota                  | Descrição                          |
|--------|-----------------------|------------------------------------|
| GET    | `/api/state`          | retorna todo o banco               |
| POST   | `/api/<colecao>`      | cria um registro                   |
| PUT    | `/api/<colecao>/<id>` | atualiza um registro               |
| DELETE | `/api/<colecao>/<id>` | remove um registro                 |
| PUT    | `/api/config`         | salva preferências                 |
| POST   | `/api/reset`          | apaga tudo e recria os exemplos    |
| POST   | `/api/import`         | restaura um backup JSON            |

## Inspecionar o banco (opcional)

```bash
sqlite3 sigoe.db "SELECT nome, disciplina FROM professores;"
```
